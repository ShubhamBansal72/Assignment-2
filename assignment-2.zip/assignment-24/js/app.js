$(document).ready(function () {
	let stickyNavTop = $('.navbar').offset().top;

	let stickyNav = function () {
		let scrollTop = $(window).scrollTop();
		if (scrollTop > stickyNavTop) {
			$('.navbar').addClass('sticky');
		} else {
			$('.navbar').removeClass('sticky');
		}
	};

	stickyNav();
	$(window).scroll(function () {
		stickyNav();
	});
});

function myFunction() {
	let x = document.getElementById("myLinks");
	if (x.style.display === "block") {
		x.style.display = "none";
	} else {
		x.style.display = "block";
	}
}

$(document).ready(function () {
	let $slider = $(".slider-content");
	let $pagination = $(".btn-wrap h4");

	$slider.slick({
		slidesToShow: 1.3,
		slidesToScroll: 1,
		arrows: true,
		infinite: false,
		autoplay: false,
		responsive: [
			{
				breakpoint: 991,
				settings: {
					slidesToShow: 1.5,
				}
			},
			{
				breakpoint: 557,
				settings: {
					slidesToShow: 1.5,
				}
			}
		]
	});

	$(".prev-btn").click(function () {
		$slider.slick("slickPrev");
	});

	$(".next-btn").click(function () {
		$slider.slick("slickNext");
	});

	$(".prev-btn").addClass("slick-disabled");

	$slider.on("afterChange", function (event, slick, currentSlide) {
		let currentIndex = currentSlide + 1;
		let totalSlides = slick.slideCount;
		$pagination.text(currentIndex + '/' + totalSlides);

		if ($(".slick-prev").hasClass("slick-disabled")) {
			$(".prev-btn").addClass("slick-disabled");
		} else {
			$(".prev-btn").removeClass("slick-disabled");
		}

		if ($(".slick-next").hasClass("slick-disabled")) {
			$(".next-btn").addClass("slick-disabled");
		} else {
			$(".next-btn").removeClass("slick-disabled");
		}
	});
});

let titleMain = $("#animatedHeading");

let titleSubs = titleMain.find("slick-active");

if (titleMain.length) {

	titleMain.slick({
		autoplay: false,
		arrows: false,
		dots: false,
		slidesToShow: 1,
		centerPadding: "10px",
		draggable: false,
		infinite: true,
		pauseOnHover: false,
		swipe: false,
		touchMove: false,
		vertical: true,
		speed: 1000,
		dots: true,
		autoplaySpeed: 20000,
		useTransform: true,
		cssEase: 'cubic-bezier(0.645, 0.045, 0.355, 1.000)',
		adaptiveHeight: true,
	});

	titleMain.slick('slickPlay');
};

window.onload = function () {
	$('.slider').slick({
		autoplay: true,
		autoplaySpeed: 1500,
		arrows: true,
		prevArrow: '<button type="button" class="slick-prev"></button>',
		nextArrow: '<button type="button" class="slick-next"></button>',
		centerMode: true,
		slidesToShow: 3,
		slidesToScroll: 1,
		responsive: [
			{
				breakpoint: 991,
				settings: {
					slidesToShow: 2,
				}
			},
			{
				breakpoint: 557,
				settings: {
					slidesToShow: 1,
				}
			}
		]
	});
};

document.addEventListener('DOMContentLoaded', function () {
	let elems = document.querySelectorAll('.carousel');
});

$(document).ready(function () {
	$('.carousel').carousel();
});

$(document).ready(function () {
	$(".carousel").carousel();
	$(".next").click(function () {
		$(".carousel").carousel("next");
	});
	$(".prev").click(function () {
		$(".carousel").carousel("prev");
	});

});

$(document).ready(function () {
	if ($(window).width() <= 557) {
		$(".togg").click(function () {
			$(this).siblings("ul").toggle();
			$(this).find('i').toggleClass('fa-angle-down fa-angle-up');
		});
	}
});